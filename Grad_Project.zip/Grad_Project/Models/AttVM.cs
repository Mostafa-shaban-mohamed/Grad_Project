﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Grad_Project.Models
{
    public class AttVM
    {
        public string[] StudentID { get; set; }
        public string CourseID { get; set; }
    }
}